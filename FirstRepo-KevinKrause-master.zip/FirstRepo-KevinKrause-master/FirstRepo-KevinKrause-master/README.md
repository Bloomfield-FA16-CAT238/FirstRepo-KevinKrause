# FirstRepo-KevinKrause

# Heading 1
## Heading 2
###### Heading 3

Doing Quotes:
> Rip...

**Bold text**
*Italicized text*
**_Both_**

- What To
- Dont Know
- Put Here

1. Eat
2. Sleep
3. Game
4. Repeat

Done with help of [Cheat Sheet](https://help.github.com/articles/basic-writing-and-formatting-syntax/)

[Images] (https://cdn-enterprise.discourse.org/turtlerock/uploads/default/original/3X/9/9/99f2ea4f3374fa75a7a1b43997c1261224ead9cd.jpg)

~~This was a grave mistake~~

Life of a College Student
- [x] Finish this
- [x] Finish that
- [ ] Sleep
- [x] Other things

:hushed:
